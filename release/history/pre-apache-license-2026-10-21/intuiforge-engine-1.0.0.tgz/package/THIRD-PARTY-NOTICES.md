# Third-party notices

The versioned local package includes third-party code and assets. Their license texts and notices are retained beside their source files in the package:

- RichViz 0.5.0: `packages/visualization-legacy/vendor/RichViz-main/LICENSE`, `NOTICE`, and `THIRD_PARTY_NOTICES.md`.
- Visualization engines: `packages/visualization-legacy/vendor/RichViz-main/External-Libraries/` (including each engine's `LICENSE`, `NOTICE`, and `THIRD-PARTY-NOTICES.txt` files).
- Captiva application icons: `packages/visualization-legacy/asset-library/Assets/Application-Icons/Captiva/LICENSE` and `README.md`.
- Visual catalog: `packages/visualization-legacy/asset-library/Assets/catalog.json` records per-asset authors, origins, license identifiers, attribution and SHA-256 values.

No notice is replaced by an IntuiForge-wide license. The package remains private and `UNLICENSED`; see `LICENSES/README.md` before creating any external distribution.
